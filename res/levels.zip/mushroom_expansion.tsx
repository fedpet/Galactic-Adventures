<?xml version="1.0" encoding="UTF-8"?>
<tileset name="spritesheet" tilewidth="70" tileheight="70" spacing="1" tilecount="49" columns="7">
 <image source="mushroom_expansion.png" width="512" height="512"/>
</tileset>
