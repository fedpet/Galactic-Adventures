<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles_spritesheet" tilewidth="70" tileheight="70" spacing="2" tilecount="156" columns="12">
 <image source="tiles_spritesheet.png" width="914" height="936"/>
</tileset>
