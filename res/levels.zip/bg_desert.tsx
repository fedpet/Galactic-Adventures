<?xml version="1.0" encoding="UTF-8"?>
<tileset name="bg_desert" tilewidth="70" tileheight="70" tilecount="98" columns="14">
 <image source="bg_desert.png" width="1024" height="512"/>
</tileset>
