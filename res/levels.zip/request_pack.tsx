<?xml version="1.0" encoding="UTF-8"?>
<tileset name="sheet" tilewidth="70" tileheight="70" tilecount="98" columns="14">
 <image source="request_pack.png" width="980" height="490"/>
</tileset>
