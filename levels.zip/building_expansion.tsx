<?xml version="1.0" encoding="UTF-8"?>
<tileset name="sheet" tilewidth="70" tileheight="70" tilecount="98" columns="14">
 <image source="building_expansion.png" width="980" height="490"/>
</tileset>
